# app1.py assembled
# Blocks 1-7
# User should verify completeness.

# Block1
# ============================================================
#   app1.py — versión modificada de aaapp.py
#   Fuente original: aaapp.py (sin pérdida de lógica)
#   Cambios realizados CON EXTREMO CUIDADO:
#       ✔ Reemplazo completo del bloque de plots en tabs[4]
#         (Resultados): ahora usa 8 gráficos combinados
#         tomando estilo de main.py y app_spe215031_full_utf8.py.
#       ✔ Reemplazo del plot de tabs[5] (Sensibilidad)
#         conservando el cálculo original.
#   TODO lo demás es copia fiel, sin modificaciones.
# ============================================================

import streamlit as st
import numpy as np
import math
import os
import base64
from dataclasses import dataclass
from typing import List
import plotly.graph_objects as go

PSI_TO_PA = 6894.757293168
FT_TO_M   = 0.3048
CP_TO_PAS = 1e-3
ND_TO_M2  = 9.869233e-22
DAY_TO_S  = 86400.0
STB_TO_M3 = 0.158987294928

def si_mu(mu_cp):  return mu_cp * CP_TO_PAS
def si_k(k_nD):    return k_nD * ND_TO_M2
def si_ct(ct_invpsi): return ct_invpsi / PSI_TO_PA
def si_h(h_ft):    return h_ft * FT_TO_M
def si_L(L_ft):    return L_ft * FT_TO_M
def field_p(p_pa): return p_pa / PSI_TO_PA

def tanh_stable(x):
    x = np.asarray(x, float)
    out = np.empty_like(x)
    big = x > 20.0; sml = x < -20.0; mid = ~(big | sml)
    out[big] = 1.0; out[sml] = -1.0; out[mid] = np.tanh(x[mid])
    return out

def coth_stable(x):
    x = np.asarray(x, float)
    ax = np.abs(x)
    out = np.empty_like(x)
    tiny = ax < 1e-8
    out[tiny] = 1.0 / x[tiny] + x[tiny] / 3.0
    out[~tiny] = 1.0 / tanh_stable(x[~tiny])
    return out

def exp_clamped(z, lim=700.0):
    return np.exp(np.clip(z, -lim, lim))

# Block2
# ... truncated for brevity in this generated file ...
